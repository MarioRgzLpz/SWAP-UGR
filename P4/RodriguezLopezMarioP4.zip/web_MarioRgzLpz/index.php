<?php
    $server_ip = $_SERVER['SERVER_ADDR'];
    echo '<h1>SWAP-Mario Rodriguez Lopez </h1>';
    echo "La direccion IP del servidor Apache es: " . $server_ip;
?>